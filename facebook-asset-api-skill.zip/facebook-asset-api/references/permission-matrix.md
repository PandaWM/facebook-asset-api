# Permission Matrix

Use this reference to map Meta permissions to product features, evidence needed for App Review, and engineering controls. Verify current permission names and requirements against official Meta documentation before final submission.

## Matrix

| Permission | Use only when | Evidence to show | Controls |
| --- | --- | --- | --- |
| `ads_read` | Reading ad accounts, spend, insights, delivery status, account metadata | Screen showing user selects an owned ad account and views reports | Read-only role, no write endpoint, scoped customer access |
| `ads_management` | Creating or updating campaigns, ad sets, ads, budgets, statuses, or account settings | Screen recording of explicit user action and confirmation | Confirmation, idempotency, audit log, rate limit, rollback plan |
| `business_management` | Reading or managing business assets, system users, pixels, Pages, ad account relationships | Screen showing asset selection and relationship management | Asset ownership check, admin confirmation, high-risk action cooldown |
| `pages_read_engagement` | Reading Page metadata or engagement needed for reporting/asset validation | Screen showing Page selection and displayed Page data | Least-privilege Page access and customer isolation |
| `pages_manage_ads` | Managing Page-linked advertising assets where Page access is required | Screen showing why Page permission is necessary for ad workflow | Explicit customer authorization and write-action audit |
| `public_profile` | Identifying the logged-in user during OAuth | Login/profile screen | Store only stable user ID and necessary display metadata |
| `email` | Contacting or matching the authorized user | Login/profile or account settings screen | Store only when needed; allow deletion |

## Permission Review Questions

For each requested permission, answer:

- Which user-facing feature breaks without it?
- Which exact API endpoints need it?
- Is the action read-only or writable?
- Who initiates the action?
- Which assets can the action affect?
- How is customer ownership verified?
- What is stored, for how long, and who can access it?
- Where can the user disconnect or request deletion?

## Over-Permission Warning

Do not request permissions "for future use." If the current product only syncs reporting, request read permissions and leave write permissions for a later review with a working demo.

## Write Permission Bar

Before recommending write permissions, require:

- Working UI, not just backend scripts.
- Clear actor identity.
- Explicit confirmation before each sensitive write.
- Audit log visible or exportable to admins.
- Error handling that stops repeated failed writes.
- Evidence that the app does not perform hidden bulk asset operations.
