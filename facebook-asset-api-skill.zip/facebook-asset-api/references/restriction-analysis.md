# Restriction Analysis

Use this reference when investigating BM, ad account, app, pixel, or business portfolio restrictions.

## Evidence Collection

Collect:

- Restricted BM ID and name.
- Restriction date and Meta message.
- Review status and review result.
- Parent BM ID.
- App ID.
- System User ID.
- Admin and employee users.
- Ad accounts linked before restriction.
- Pixels linked before restriction.
- Pages/domains/payment methods involved.
- API actions in the 72 hours before restriction.
- Browser/manual actions in the 72 hours before restriction.

Do not request cookies, passwords, full browsing history, or raw tokens. Screenshots, copied page text, and redacted HAR files are safer.

## Timeline Method

Build a timeline with:

1. BM creation.
2. Admin/user additions.
3. App/system user authorization.
4. Ad account creation or assignment.
5. Pixel binding.
6. Page/domain/payment changes.
7. First failed API call.
8. First repeated retry.
9. Restriction event.
10. Review request and result.

Then compare multiple restricted BMs for shared assets.

## Common High-Risk Patterns

Flag these patterns:

- Same parent BM across restricted child BMs.
- Same app ID across restricted BMs.
- Same system user across restricted BMs.
- Same operator/IP performing many writes.
- Same pixel bound to many ad accounts quickly.
- Same naming template or prefix across BMs/ad accounts.
- Many ad accounts created or assigned within minutes.
- High retry count for user invites or bindings.
- New BM immediately linked to many assets.
- Restricted asset reused in new BMs.

## Confidence Levels

Use:

- **High confidence**: Multiple restricted BMs share the same parent BM, app, system user, and action pattern.
- **Medium confidence**: Strong temporal clustering or repeated failures, but missing full API logs.
- **Low confidence**: Only one restricted BM or incomplete data.

Always distinguish evidence from inference.

## Recommended Response

For a suspected automation-like restriction:

- Pause high-risk writes for the affected parent BM/app/system user.
- Stop retries for failed binding/invitation operations.
- Mark related assets as "restriction risk" internally.
- Keep read-only syncs if permitted and useful.
- Prepare truthful review materials, not evasive explanations.
- Add product controls before resuming writes.

## What Not To Recommend

Do not recommend:

- Creating more BMs to replace restricted ones.
- Rotating fingerprints, cookies, IPs, or accounts to continue the same workflow.
- Reusing restricted pixels, apps, domains, payment methods, or users without analysis.
- Hiding automation from Meta.
- Fabricating business identity or user intent.
