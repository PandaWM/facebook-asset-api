# API Design

Use this reference for designing Facebook asset management API services.

## Core Architecture

Prefer:

- Backend-only Graph API and Marketing API calls.
- OAuth authorization through Meta's standard flow.
- Encrypted token storage.
- Short-lived user token exchange to long-lived token only when appropriate.
- System User tokens only for business-owned, server-side workflows with clear scope.
- A typed internal asset model instead of ad hoc IDs in text fields.

Avoid:

- Running API calls from fingerprint browsers.
- Storing tokens in browser local storage.
- Sharing one system user across unrelated customers without access boundaries.
- Treating one app/system user as a universal control plane for all assets.

## Asset Model

Track at minimum:

- `business_id`
- `business_name`
- `parent_business_id`
- `app_id`
- `system_user_id`
- `facebook_user_id`
- `ad_account_id`
- `pixel_id`
- `page_id`
- `customer_id`
- `team_id`
- `asset_status`
- `restriction_status`
- `created_at`
- `last_synced_at`
- `source`

For relationships, include:

- `relationship_type`
- `granted_by`
- `granted_at`
- `revoked_at`
- `permission_scopes`
- `meta_response_id`
- `operation_id`

## Endpoint Categories

Classify internal endpoints by risk.

### Read-only

- Sync BM metadata.
- Sync ad account status.
- Sync spend/insights.
- Sync pixels.
- Sync app/system user relationships.

### Controlled write

- Assign one ad account to one customer.
- Bind one pixel to one ad account.
- Invite one known user.
- Update internal notes or status.

### Bulk or scheduled

- Batch sync spend.
- Batch status refresh.
- Batch reconciliation.

Do not mix bulk jobs with sensitive write operations unless the product has explicit safeguards.

## Idempotency

Every write action should include:

- Stable `operation_id`.
- Idempotency key.
- Actor ID.
- Asset IDs.
- Precondition checks.
- Meta request ID or response ID.
- Final status.

Duplicate submissions should return the existing operation result instead of repeating the Meta API call.

## Error Handling

Capture:

- HTTP status.
- Meta error code and subcode.
- Error message.
- Request path without tokens.
- Retryability decision.
- Backoff schedule.
- Final state.

Do not blindly retry permission, policy, integrity, or restriction errors. Repeated retries can become a risk signal.

## Secret Handling

Never log:

- `access_token`
- `app_secret`
- `client_secret`
- OAuth `code`
- Cookie values
- Passwords
- Authorization headers

Use structured redaction before persistence. Redaction must happen before logs reach a database, queue, analytics system, or error tracker.
