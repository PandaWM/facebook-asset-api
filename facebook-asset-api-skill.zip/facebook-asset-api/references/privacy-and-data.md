# Privacy And Data

Use this reference when reviewing privacy policy, data deletion, storage, retention, or token handling for Facebook asset management.

## Data Categories

Classify stored data:

- Account identity: Facebook user ID, business ID, ad account ID, Page ID.
- Asset metadata: names, statuses, relationships, timestamps.
- Reporting data: spend, impressions, clicks, conversions, balances.
- Operational data: audit logs, API errors, request IDs, retry counts.
- Secrets: access tokens, refreshable/long-lived tokens, app secrets, cookies, passwords.

Secrets require special handling and should never appear in normal logs.

## Data Minimization

Store only what supports the product feature. Prefer stable IDs and derived status over full raw API responses. Avoid storing unrelated profile, browsing, or personal data.

## Token Handling

Require:

- Server-side token exchange.
- Encryption at rest.
- Restricted database access.
- Token rotation and revocation handling.
- No tokens in frontend code, logs, URLs, screenshots, analytics, or error trackers.
- Separate development, staging, and production apps/tokens.

## Deletion And Disconnect

Provide a path to:

- Disconnect a Meta account or business.
- Delete stored user data.
- Delete or anonymize reporting snapshots when required.
- Revoke tokens.
- Preserve minimal audit records only when legally or operationally necessary.

For App Review, document where the user can request deletion and how the deletion callback or manual process works.

## Privacy Policy Content

Include:

- What Meta data is collected.
- Why it is collected.
- How it is used.
- Who can access it.
- How long it is retained.
- How users revoke access.
- How users request deletion.
- Contact method for privacy requests.

## Log Redaction

Before storage, redact:

- Access tokens.
- App secrets.
- OAuth codes.
- Passwords.
- Cookies.
- Authorization headers.
- Client secrets.
- Payment credentials.

Use allowlisted structured fields instead of storing raw request bodies by default.
