# Implementation Checklists

Use these checklists when planning or reviewing a Facebook asset management API implementation.

## Pre-Launch Checklist

- Confirm each permission maps to a shipped feature.
- Pin and document the Graph API and Marketing API versions used by every integration.
- Verify OAuth redirect URIs and app domains.
- Implement token encryption and revocation handling.
- Add role-based access control for customer/team assets.
- Add audit logs for every API action.
- Add secret redaction before persistence.
- Add idempotency for write actions.
- Add rate limits per BM, app, system user, customer, operator, and action.
- Add stop conditions for restriction, permission, and repeated failure errors.
- Test disconnect and data deletion flow.
- Prepare App Review screencast and test credentials.

## API Version Upgrade Checklist

- Read the official Meta changelog for the target version and the next planned version.
- Search code, scheduled jobs, report builders, and stored query templates for deprecated fields.
- Search for `metadata=1`; replace dynamic metadata probing with official references or maintained field allowlists.
- Check Page, Post, Video, and Story Insights metrics for deprecated impressions/reach/unique views fields.
- Add replacement media-view metrics where Meta provides alternatives.
- Verify Marketing API campaign creation/copy/update flows against current campaign structure requirements.
- Verify asynchronous insights job failure parsing and store `error_code`, `error_message`, `error_subcode`, `error_user_title`, and `error_user_msg`.
- Treat `error_code` as a signed integer where the API version expects it.
- Test webhook delivery after any mTLS root CA or certificate-chain change.
- Run read-only smoke tests before enabling writes on the new version.
- Keep rollback instructions for version pinning where supported.

## Production Guardrails

- Default to read-only syncs.
- Queue bulk reads separately from writes.
- Require confirmation for high-risk writes.
- Block writes for restricted or recently restricted BMs.
- Pause writes when parent BM, app, or system user shows clustered failures.
- Limit new BM asset linking during an observation period.
- Review dashboards for retry spikes and policy/integrity errors daily.

## Incident Checklist

When a BM is restricted:

- Freeze writes for that BM.
- Freeze writes for shared parent BM/app/system user if multiple BMs are affected.
- Export 72-hour timeline.
- List shared assets with other restricted BMs.
- Count write actions by category.
- Count retries and failures.
- Check recent user/admin invitations.
- Check recent pixel bindings.
- Check recent ad account assignments.
- Preserve evidence for review without exposing secrets.

## App Review Checklist

- Remove internal or risky terminology from demo UI.
- Use real user paths, not backend-only scripts.
- Show least-privilege access.
- Show confirmation for writes.
- Show auditability.
- Show disconnect/deletion path.
- Explain data retention.
- Use a clean test account with only necessary assets.

## Engineering Backlog Ideas

- `asset_risk_score` field.
- `restriction_status` and `restriction_detected_at`.
- `parent_business_id` on every BM and ad account record.
- `system_user_id` on every API operation.
- `operation_batch_id` for bulk jobs.
- `cooldown_until` for sensitive writes.
- `last_meta_error_code` and `last_meta_error_subcode`.
- Admin dashboard for risky action clusters.
- API version inventory by endpoint/job.
- Deprecated field scanner for Graph API and Marketing API requests.
