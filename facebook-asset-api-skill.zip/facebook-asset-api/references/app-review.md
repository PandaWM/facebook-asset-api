# App Review And Permissions

Use this reference when preparing Meta App Review materials, explaining permissions, or reviewing whether a Facebook App/API workflow is truthful and reviewable.

## Positioning

Describe the product as a business asset management tool only if that is true. Avoid language that implies:

- Creating accounts at scale for resale.
- Circumventing restrictions.
- Reusing restricted assets.
- Automating human account behavior.
- Hiding the real actor behind API calls.

Good positioning:

- "The app helps authorized business customers view and manage their owned ad accounts, pixels, and spend data."
- "Admins use the tool to process customer-requested asset management tasks with audit logs and explicit confirmation."
- "The system synchronizes asset status and spend for reporting and support."

## Review Package Checklist

Prepare:

- Business description and product URL.
- Privacy Policy URL and Terms URL.
- Data deletion callback or instructions.
- Screencast showing the exact user path for each permission.
- Test credentials with least privilege.
- Clear permission-to-feature mapping.
- Example customer support scenario, if back-office actions are involved.
- Explanation of stored data, retention, access control, and deletion.
- Evidence that sensitive actions are user-initiated or admin-confirmed.

## Common Permission Narratives

Adapt only to the actual product behavior.

### `ads_read`

Use for reading ad account metadata, delivery status, spend, insights, and account health for reporting, reconciliation, and support. Do not claim this permission is needed for creating or changing ads.

### `ads_management`

Use only when the product creates or updates campaigns, ad sets, ads, budgets, account settings, or other writable ad objects. State exactly which objects can be changed and whether the action is user-initiated.

### `business_management`

Use for business asset relationships such as reading BMs, system users, assigned ad accounts, pixels, Pages, or business-owned assets. For writable use, describe the exact actions, confirmation steps, and audit logs.

### Page permissions

Use Page permissions only when the product must read or manage Page-related assets. Do not request Page permissions for ad account reporting alone.

## Reviewer-Friendly Demonstration

The demo should show:

1. Login or admin authentication.
2. Customer/BM selection.
3. Asset list loaded from Meta API.
4. A read-only report or status sync.
5. One write action if requested, with confirmation and visible audit logging.
6. Where users can revoke/disconnect access.
7. Where data deletion is requested.

## Red Flags To Remove Before Review

- Buttons or copy that imply "batch create BM", "bulk bind accounts", "auto warm", "fingerprint browser", "recycle accounts", or "bypass restriction".
- Screens showing many unrelated customers' assets under one test account.
- Logs or pages showing access tokens, passwords, app secrets, cookies, or raw OAuth codes.
- Workflows that perform many asset assignments without a visible actor and confirmation.

## Truthful Answers For Restrictions

If the user asks why a BM or app is restricted, do not invent certainty. Report:

- What Meta shows as the reason.
- Which assets and actions are linked in the system.
- Which patterns look automation-like.
- What evidence is missing.
- What actions should pause until review is complete.
