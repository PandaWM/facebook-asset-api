# Version Upgrades

Use this reference when reviewing Graph API or Marketing API version changes. Always verify current deadlines and behavior against official Meta documentation before making final production decisions.

## Upgrade Workflow

1. Inventory every Graph API and Marketing API call:
   - API version
   - endpoint
   - fields
   - permissions
   - caller/job name
   - read/write classification
   - customer-facing feature
2. Read the official changelog for the target version and the next version.
3. Classify each change:
   - breaking now
   - breaking on a future date
   - deprecated but still working
   - behavior change
   - new field or error detail
4. Search code and stored configs for affected endpoints, fields, metrics, and parameters.
5. Update field allowlists, reports, parsers, and retry logic.
6. Run read-only smoke tests.
7. Run write tests only in a safe test environment.
8. Update App Review materials if permission usage or user flows changed.
9. Add monitoring for new errors after rollout.

## v25.0 Notes

Official source: `https://developers.facebook.com/docs/graph-api/changelog/version25.0/`

Graph API v25.0 was released February 18, 2026. The items below are operational notes, not a substitute for the official changelog.

### Insights Metric Deprecations

When v26.0 is released, Meta says several Page/Post/Video/Story reach, impressions, and unique view metrics will be deprecated across all versions and return errors when requested.

Check for old metrics such as:

- `page_impressions_unique`
- `page_impressions_paid_unique`
- `page_posts_impressions`
- `page_posts_impressions_unique`
- `post_impressions_unique`
- `post_impressions_paid_unique`
- `post_video_views_unique`
- `total_video_impressions`
- `total_video_impressions_unique`
- `total_video_views_unique`
- `PAGE_STORY_IMPRESSIONS_BY_STORY_ID`
- `PAGE_STORY_IMPRESSIONS_BY_STORY_ID_UNIQUE`

Use Meta's listed alternatives where available, such as:

- `page_total_media_view_unique`
- `page_media_view`
- `post_total_media_view_unique`
- `post_media_view`
- `STORY_MEDIA_VIEW`
- `STORY_TOTAL_MEDIA_VIEW_UNIQUE`

If Meta lists no alternative, remove the report field or mark the data unavailable.

### `metadata=1` Deprecation

For v25.0+, the `metadata=1` query parameter is deprecated for node field metadata. Meta states this applies to all versions from May 19, 2026.

Action:

- Search for `metadata=1`.
- Remove runtime field-discovery logic that depends on it.
- Maintain explicit field allowlists per endpoint.
- Use Graph API Explorer and official API references for field discovery.

### Webhooks mTLS Certificate Change

Meta states that starting March 31, 2026, Webhooks mTLS certificates are signed by a new Meta-owned CA while keeping the common name `client.webhooks.fbclientcerts.com`.

Action:

- Check whether webhook receivers require and verify Meta mTLS client certificates.
- Add Meta's new root CA to the trust store before the deadline.
- Test webhook delivery and TLS handshake behavior.
- Monitor webhook delivery failures during rollout.

### Marketing API Advantage+ Changes

For v25.0+, creation, duplication, and updates to deprecated Advantage+ Shopping Campaigns and Advantage+ App Campaigns are no longer allowed. Meta states the change applies to all versions from May 19, 2026.

Affected endpoints include:

- `POST /{ad-account-id}/campaigns`
- `POST /{campaign-id}/copies`

Action:

- Search campaign creation and copy workflows.
- Identify old Advantage+ Shopping/App Campaign structures.
- Migrate to the current Advantage+ Campaigns structure.
- Update UI labels and templates so users do not create unsupported campaign types.

### Async Insights Job Errors

For v25.0+, failed asynchronous ad reports return additional default fields:

- `error_code`
- `error_message`
- `error_subcode`
- `error_user_title`
- `error_user_msg`

Meta also notes that `error_code` changes from `uint` to `int` for developers with access to the field.

Action:

- Store all new failure fields.
- Parse `error_code` as signed integer.
- Add dashboards for recurring `error_subcode` values.
- Stop blind retries for permission, restriction, integrity, or invalid parameter errors.

## Upgrade Report Questions

When reporting an upgrade review, answer:

- Which API versions are currently used?
- Which endpoints are affected?
- Which fields or metrics are deprecated?
- Which jobs will fail after the deadline?
- What user-visible reports or workflows change?
- What tests prove the new version works?
- What monitoring will detect regressions?
