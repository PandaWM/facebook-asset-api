# Output Templates

Use these templates for consistent deliverables.

## API Design Review

```markdown
**Scope**
- Product feature:
- Meta assets involved:
- Permissions:
- Read/write actions:

**Findings**
- [P0/P1/P2] Finding:
- Evidence:
- Risk:
- Recommendation:

**Architecture Changes**
- OAuth/token:
- Data model:
- API boundaries:
- Audit logging:
- Rate limits:

**Open Questions**
- ...
```

## App Review Permission Narrative

```markdown
**Permission:** `permission_name`

**Feature requiring this permission**
Describe the exact user-facing feature.

**User steps**
1. User logs in.
2. User selects the owned business/ad account/Page.
3. User performs or views the specific feature.

**API usage**
- Endpoint/object:
- Read or write:
- Data stored:

**Why lower privilege is insufficient**
Explain why a narrower permission or no permission will not work.

**Safety controls**
- Confirmation:
- Audit logging:
- Deletion/disconnect:
- Rate limits:
```

## Restriction Analysis Report

```markdown
**Restricted asset**
- BM ID:
- BM name:
- Restriction date:
- Meta reason:
- Review status:

**Shared risk links**
- Parent BM:
- App ID:
- System User:
- Admin users:
- Pixels:
- Ad accounts:
- Domains/payment methods:

**72-hour timeline**
- Time | Actor | Action | Asset | Result | Error

**Likely causes**
1. Cause | Confidence | Evidence
2. Cause | Confidence | Evidence

**Immediate actions**
- Pause:
- Isolate:
- Review:

**Engineering fixes**
- Logging:
- Rate limits:
- UI confirmations:
- Data model:
```

## Risk Finding Format

```markdown
**[Severity] Title**
Evidence: concrete IDs, timestamps, endpoints, or logs.
Impact: why this can cause policy, integrity, privacy, or operational risk.
Fix: the smallest practical change.
Verification: how to prove the fix works.
```

## API Version Upgrade Report

```markdown
**Version Scope**
- Current version(s):
- Target version:
- Official changelog:
- Deadline / enforcement date:

**Affected Surfaces**
- Endpoint/job:
- Fields/metrics:
- Permission:
- Read/write:
- User-facing feature:

**Breaking Or Deprecated Items**
- Item:
- Current usage:
- Replacement:
- Deadline:
- Owner:

**Required Changes**
- Code:
- Config/query templates:
- Reports:
- Webhooks/certificates:
- Logging/error parsing:

**Test Plan**
- Read-only smoke tests:
- Write tests:
- Webhook tests:
- Report comparisons:

**Rollout Plan**
- Deploy order:
- Monitoring:
- Rollback:
```
