# Audit And Controls

Use this reference when designing logs, risk controls, rate limits, and operational guardrails for Facebook asset management.

## Audit Log Schema

Record one audit event per user action, job action, and Meta API request.

Recommended fields:

- `operation_id`
- `parent_operation_id`
- `timestamp`
- `actor_type`: user, admin, system_job, webhook
- `actor_id`
- `operator_ip`
- `customer_id`
- `team_id`
- `business_id`
- `parent_business_id`
- `app_id`
- `system_user_id`
- `facebook_user_id`
- `ad_account_id`
- `pixel_id`
- `page_id`
- `endpoint`
- `http_method`
- `permission_scopes`
- `action_category`
- `risk_level`
- `source_ui`
- `confirmation_id`
- `idempotency_key`
- `status`
- `meta_error_code`
- `meta_error_subcode`
- `retry_count`
- `duration_ms`

Store request/response bodies only after strict redaction.

## Sensitive Actions

Require confirmation and a reason for:

- Inviting or removing BM users.
- Changing admin roles.
- Assigning or unassigning ad accounts.
- Binding pixels to ad accounts.
- Linking apps, system users, or Pages.
- Changing ad account type, payment, or ownership metadata.
- Retrying failed binding or invitation jobs.

## Rate Limits And Cooldowns

Create conservative limits per:

- Business ID
- Parent business ID
- App ID
- System User ID
- Facebook User ID
- Customer/team
- Operator
- IP or server worker identity
- Action category

Example guardrails:

- One sensitive write per BM per short window.
- Pause after repeated failures.
- Cooldown newly created BMs before linking many assets.
- Block bulk writes against restricted or recently reviewed BMs.
- Queue bulk reads separately from write actions.

## Risk Score Inputs

Increase risk when:

- A BM is new.
- A BM has a recent restriction.
- A parent BM has multiple restricted child BMs.
- Many assets share one app or system user.
- Many actions happen within seconds.
- Names are template-like across many assets.
- Failures and retries cluster around one action type.
- A pixel is bound to many ad accounts quickly.
- Many ad accounts are assigned to one customer in one operation.

Decrease risk when:

- Asset owner and customer are verified.
- User action is explicit and recent.
- Business identity and domain are verified.
- Asset relationships are stable over time.
- Prior operation history is low volume and successful.

## Stop Conditions

Automatically pause jobs when:

- Meta returns integrity, policy, permission, checkpoint, or restriction errors.
- A BM becomes restricted.
- A related parent BM is restricted.
- A system user token starts failing across multiple BMs.
- A repeated operation fails more than the configured threshold.
- A single operator initiates many high-risk actions quickly.

The pause should block further writes and allow read-only diagnostics.
